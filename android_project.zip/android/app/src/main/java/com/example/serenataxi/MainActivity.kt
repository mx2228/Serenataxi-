package com.example.serenataxi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {}
